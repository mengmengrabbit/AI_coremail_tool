from flask import Flask, render_template, jsonify, request
import sys
import os

# 添加项目根目录到系统路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

# 导入模块
from src.core.email_manager import EmailManager
from tests.test_emails import TestEmailManager
from datetime import datetime

# 设置模板和静态文件目录
app = Flask(__name__, 
           template_folder=os.path.abspath(os.path.join(os.path.dirname(__file__), '../../templates')),
           static_folder=os.path.abspath(os.path.join(os.path.dirname(__file__), '../../static')))

# 尝试使用真实的邮件管理器，如果失败则使用测试数据
try:
    email_manager = EmailManager()
    # 测试是否能访问邮件文件夹
    test_reminders = email_manager.get_patent_examination_reminders()
    print(f"使用真实邮件数据，找到 {len(test_reminders)} 条提醒")
except Exception as e:
    print(f"无法访问真实邮件文件夹: {e}")
    print("使用测试数据模式")
    email_manager = TestEmailManager()

@app.route('/')
def index():
    """主页面"""
    return render_template('index.html')

@app.route('/api/patent-examination-reminders')
def get_patent_examination_reminders():
    """获取专利审查临期提醒数据"""
    try:
        reminders = email_manager.get_patent_examination_reminders()
        
        # 转换datetime对象为字符串
        for reminder in reminders:
            if isinstance(reminder['deadline'], datetime):
                reminder['deadline_str'] = reminder['deadline'].strftime('%Y年%m月%d日')
                reminder['deadline_iso'] = reminder['deadline'].isoformat()
                # 计算距离今天的天数
                days_left = (reminder['deadline'] - datetime.now()).days
                reminder['days_left'] = days_left
                reminder['urgency_level'] = 'high' if days_left <= 7 else 'medium' if days_left <= 30 else 'low'
        
        return jsonify({
            'success': True,
            'data': reminders,
            'count': len(reminders)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/patent-certificates')
def get_patent_certificates():
    """获取专利授权证书汇总"""
    return jsonify({
        'success': True,
        'data': [],
        'message': '功能待实现'
    })

@app.route('/api/patent-invoices')
def get_patent_invoices():
    """获取专利费用发票汇总"""
    return jsonify({
        'success': True,
        'data': [],
        'message': '功能待实现'
    })

@app.route('/api/software-notices')
def get_software_notices():
    """获取软件协会通知汇总"""
    return jsonify({
        'success': True,
        'data': [],
        'message': '功能待实现'
    })

@app.route('/api/stats')
def get_stats():
    """获取统计信息"""
    try:
        reminders = email_manager.get_patent_examination_reminders()
        
        # 统计紧急程度
        high_urgency = sum(1 for r in reminders if (r['deadline'] - datetime.now()).days <= 7)
        medium_urgency = sum(1 for r in reminders if 7 < (r['deadline'] - datetime.now()).days <= 30)
        low_urgency = len(reminders) - high_urgency - medium_urgency
        
        return jsonify({
            'success': True,
            'data': {
                'total_reminders': len(reminders),
                'high_urgency': high_urgency,
                'medium_urgency': medium_urgency,
                'low_urgency': low_urgency
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)